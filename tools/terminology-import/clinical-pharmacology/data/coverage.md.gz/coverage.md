# Cobertura · farmacología clínica (2026-10-30)

Universo ATC 5: **6242** (cima-maestra-atc 6029, cima-medicamentos 2237, fda-gsrs 4730, liname-bo 482, vademecum 483, ema 5, who-eeml 6). Monografías: **2883**.

Nombre mostrado por fuente: aemps-cima:maestra-atc 2835, fda-gsrs 29, código 16, liname-bo 3.

| Nivel ATC | Códigos | Con nombre ATC oficial (AEMPS) |
|---|---:|---:|
| 1 | 14 | 14 |
| 2 | 92 | 92 |
| 3 | 246 | 246 |
| 4 | 724 | 724 |
| 5 | 2883 | 2835 |

## aemps-cima

Monografías con al menos una sección: 2158 · completas: 1594 · incompletas: 564

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 2151 |
| pharmacokinetics | 1989 |
| indications | 2152 |
| posology | 1836 |
| contraindications | 2156 |
| warnings | 2152 |
| interactions | 2154 |
| adverse_reactions | 2155 |
| pregnancy_lactation | 1742 |
| overdose | 2150 |

## openfda-label

Monografías con al menos una sección: 1490 · completas: 891 · incompletas: 599

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 1395 |
| pharmacokinetics | 1393 |
| indications | 1486 |
| posology | 1488 |
| contraindications | 1393 |
| warnings | 1457 |
| interactions | 1089 |
| adverse_reactions | 1398 |
| pregnancy_lactation | 1330 |
| overdose | 1046 |

## nlm-lactmed

Monografías con al menos una sección: 1131 · completas: 0 · incompletas: 1131

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 0 |
| pharmacokinetics | 0 |
| indications | 0 |
| posology | 0 |
| contraindications | 0 |
| warnings | 0 |
| interactions | 0 |
| adverse_reactions | 0 |
| pregnancy_lactation | 1131 |
| overdose | 0 |

## niddk-livertox

Monografías con al menos una sección: 657 · completas: 0 · incompletas: 657

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 0 |
| pharmacokinetics | 0 |
| indications | 0 |
| posology | 0 |
| contraindications | 0 |
| warnings | 0 |
| interactions | 0 |
| adverse_reactions | 657 |
| pregnancy_lactation | 0 |
| overdose | 0 |

## ema-epar

Monografías con al menos una sección: 822 · completas: 0 · incompletas: 822

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 0 |
| pharmacokinetics | 0 |
| indications | 822 |
| posology | 0 |
| contraindications | 0 |
| warnings | 0 |
| interactions | 0 |
| adverse_reactions | 0 |
| pregnancy_lactation | 0 |
| overdose | 0 |

## ema-product-information

Monografías con al menos una sección: 237 · completas: 3 · incompletas: 234

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 63 |
| pharmacokinetics | 133 |
| indications | 181 |
| posology | 129 |
| contraindications | 146 |
| warnings | 173 |
| interactions | 160 |
| adverse_reactions | 8 |
| pregnancy_lactation | 181 |
| overdose | 157 |

## Catálogo de productos

No se encontraron `medicines-*.ndjson`: no se midió el cruce.

## Huecos

- LINAME (esenciales de Bolivia) sin monografía: 54
- Universo sin monografía: 3359
- universe: 6242
- monographs: 2883
- sections: 81075
- cimaProductsWithoutAtc5: 468
- cimaDocsMissing: 0
- cimaSectionsWithoutVersion: 0
- cimaSectionsVersionUnpublished: 11552
- cimaDuplicateSections: 1107
- skippedWithoutData: 3359
- uniiWithoutLabel: 1193
- fdaRefsWithoutLabel: 0
- fdaRefsWithoutMappedSections: 48
- fdaSectionsWithoutVersion: 0
- segundos: 257
