# Cobertura · farmacología clínica (2026-10-24)

Universo ATC 5: **483** (liname-bo 482, vademecum 483). Monografías: **0**.

| Nivel ATC | Códigos | Con nombre oficial |
|---|---:|---:|
| 1 | 0 | 0 |
| 2 | 0 | 0 |
| 3 | 0 | 0 |
| 4 | 0 | 0 |
| 5 | 0 | 0 |

## Catálogo de productos

No se encontraron `medicines-*.ndjson`: no se midió el cruce.

## Huecos

- LINAME (esenciales de Bolivia) sin monografía: 482
- Universo sin monografía: 483
- universe: 483
- monographs: 0
- sections: 0
- cimaProductsWithoutAtc5: 0
- openFdaLabelsScanned: 0
- cimaDocsMissing: 0
- cimaSectionsWithoutVersion: 0
- skippedWithoutData: 483
- uniiWithoutLabel: 0
- segundos: 0
