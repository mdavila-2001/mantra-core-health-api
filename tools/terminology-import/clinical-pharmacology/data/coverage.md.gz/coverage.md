# Cobertura · farmacología clínica (2026-10-24)

Universo ATC 5: **4775** (fda-gsrs 4730, liname-bo 482, vademecum 483, openfda-gsrs 834). Monografías: **1033**.

Nombre mostrado por fuente: liname-bo 198, fda-gsrs 771, código 64.

| Nivel ATC | Códigos | Con nombre ATC oficial (AEMPS) |
|---|---:|---:|
| 1 | 14 | 0 |
| 2 | 82 | 0 |
| 3 | 171 | 0 |
| 4 | 396 | 0 |
| 5 | 1033 | 0 |

## openfda-label

Monografías con al menos una sección: 1033 · completas: 678 · incompletas: 355

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 949 |
| pharmacokinetics | 947 |
| indications | 1033 |
| posology | 1033 |
| contraindications | 950 |
| warnings | 1014 |
| interactions | 767 |
| adverse_reactions | 953 |
| pregnancy_lactation | 900 |
| overdose | 792 |

## Catálogo de productos

No se encontraron `medicines-*.ndjson`: no se midió el cruce.

## Huecos

- LINAME (esenciales de Bolivia) sin monografía: 284
- Universo sin monografía: 3742
- universe: 1330
- monographs: 1033
- sections: 18853
- cimaProductsWithoutAtc5: 0
- cimaDocsMissing: 0
- cimaSectionsWithoutVersion: 0
- skippedWithoutData: 297
- uniiWithoutLabel: 0
- fdaRefsWithoutLabel: 0
- fdaRefsWithoutMappedSections: 34
- fdaSectionsWithoutVersion: 0
- segundos: 146
