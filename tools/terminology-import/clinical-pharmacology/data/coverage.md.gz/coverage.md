# Cobertura · farmacología clínica (2026-10-28)

Universo ATC 5: **6045** (cima-maestra-atc 6029, cima-medicamentos 2236, liname-bo 482, vademecum 483, ema-medicines 822). Monografías: **2963**.

| Nivel ATC | Códigos | Con nombre oficial |
|---|---:|---:|
| 1 | 14 | 14 |
| 2 | 92 | 92 |
| 3 | 248 | 248 |
| 4 | 735 | 735 |
| 5 | 2963 | 2953 |

## aemps-cima

Monografías con al menos una sección: 1531 · completas: 1506 · incompletas: 25

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 1525 |
| pharmacokinetics | 1527 |
| indications | 1526 |
| posology | 1527 |
| contraindications | 1529 |
| warnings | 1528 |
| interactions | 1527 |
| adverse_reactions | 1528 |
| pregnancy_lactation | 1519 |
| overdose | 1523 |

## openfda-label

Monografías con al menos una sección: 2008 · completas: 1216 · incompletas: 792

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 1800 |
| pharmacokinetics | 1798 |
| indications | 1999 |
| posology | 1998 |
| contraindications | 1806 |
| warnings | 1982 |
| interactions | 1404 |
| adverse_reactions | 1813 |
| pregnancy_lactation | 1793 |
| overdose | 1452 |

## ema-medicines

Monografías con al menos una sección: 822 · completas: 0 · incompletas: 822

| Requisito | Monografías que lo cubren |
|---|---:|
| mechanism | 0 |
| pharmacokinetics | 0 |
| indications | 822 |
| posology | 0 |
| contraindications | 0 |
| warnings | 0 |
| interactions | 0 |
| adverse_reactions | 0 |
| pregnancy_lactation | 0 |
| overdose | 0 |

## Catálogo de productos

No se encontraron `medicines-*.ndjson`: no se midió el cruce.

## Huecos

- LINAME (esenciales de Bolivia) sin monografía: 58
- Universo sin monografía: 3082
- universe: 6045
- monographs: 2963
- sections: 84352
- cimaProductsWithoutAtc5: 468
- openFdaLabelsScanned: 262902
- openFdaAtcWithLabels: 2035
- openFdaReferenceLabels: 2140
- cimaDocsMissing: 0
- cimaSectionsWithoutVersion: 11860
- skippedWithoutData: 3082
- uniiWithoutLabel: 630
- bridgesComplete: 2656
- bridgesIncomplete: 3389
- bridgesMissing: 0
- segundos: 228
